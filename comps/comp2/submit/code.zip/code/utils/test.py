from anchors import get_anchors

get_anchors(512)