from evaluate.evaluate import evaluate
#evaluate.evaluate("input prediction file name", "desire output csv file name")
evaluate('./test_prediction.txt', './output_file.csv')